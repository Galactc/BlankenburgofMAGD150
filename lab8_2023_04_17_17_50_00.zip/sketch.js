
var img1;
var img2;
var x =0;
var gif2;
function preload() {

	img1 = loadImage("bolt.jpg");
	img2 = loadImage("abc.png");
	gif2 = loadImage("200w.gif");


}

function setup () {

createCanvas(700, 700);
background(0);

}

function draw () {
fill(5);
stroke(2);
textSize(15);
textFont('Helvetica');
text('Invere Lightning', 333, 333);
x+= 0.01

image(img1, mouseX*-1,mouseY*-1);
image(img2, mouseY,mouseX);
image(gif2,mouseX,mouseY);
	
}