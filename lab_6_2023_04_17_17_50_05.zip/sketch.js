var x = [];
var y = [];
var z = 3;
var u = 0;
var n= 0;
var k = 2;
var m = 33;
var v =0;
var rad = 0;
 ver = true;
function setup() {
  createCanvas(700,700);
    background(200);
  colorMode(RGB,255,255,255)
  myarray = [3, 3, mouseY, z]; 
  print(myarray.length,myarray)// causes LAG
  frameRate(20) // makes things much more consistent
}

function draw() {
let myarray = []
y = mouseY
rad += 1 
  
if (ver == true)
  {
u += 0.2
     [x] = 20
  for (i = 0; i<1000; i++)
    {
     fill (n,m,k)
      ellipse(u,mouseY,n,50)
    }
          if (rad >= 222)
      {
        ver = false;
        rad = 0;
        mouseX = 0;
        mouseY = 0;
      
      }
  }
  
  
  if (ver == false)
  {
v += 10
   
   
  for (j = 0; j<1000; j++)
    {
     fill (n,m,k)
      ellipse(mouseX,v,n,50)
    }
    if (rad >= 222)
      {
        ver = true;
        rad = 0;
        mouseX = 0;
        mouseY = 0;
        v = 0;
        
      }
  }
 
  if (u > 700)
    {
      u = 0
      n = random(1, 225); 
       m = random(1, 225); 
       k = random(1, 225); 
   
    }
  if (v > 700)
    {
      v = 0
      n = random(1, 225); 
       m = random(1, 225); 
       k = random(1, 225); 
   
    }
  
}