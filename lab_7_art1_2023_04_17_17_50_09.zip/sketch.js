var x =0;
var y = 0;
var z = random(1,360)
var zz = random(1,100)
function setup() {
  createCanvas(500, 500);
   background(20);  
}

function draw() {
  z = random(1,2)
  zz = random(1,100)
  for (var i = 0; i<3; i++)
    {
  if (mouseX >350)
    {
      scale(z/10)
      rotate(zz)
 translate(x+=1,y) 
      shape()
    }
  if (mouseX <350)
    {
        scale(z/10)
      rotate(zz)
 translate(x-=1,y) 
      shape()
    }
    
   if (mouseY <350)
    {
        scale(z/10)
      rotate(zz)
 translate(x,y-=1) 
      shape()
    }
  if (mouseY >350)
    {
        scale(z/10)
      rotate(zz)
 translate(x,y+=1) 
      shape()
    }
     }

}

function shape()
{
  push()
  fill(225) 
    scale(z/10)
      rotate(zz)
  ellipse (350,350+40,220,120)
   ellipse (444,350+40,120,120)
   ellipse (350,350,200,60)
    pop()
}